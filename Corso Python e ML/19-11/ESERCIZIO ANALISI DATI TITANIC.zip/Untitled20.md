```python
import pandas as pd
```


```python
#bisogna fare una: analisi conoscitiva dei dati, valutazione delle varie colonne e degli elementi nulli sul dataset train (4)
```


```python
dataset=r"C:\Users\bugli\Desktop\GitHub\Corso-PY-e-ML\Corso Python e ML\Dataset\train (4).csv"
df=pd.read_csv(dataset)
```


```python

```


```python
#visualizzo info dataset
df.info()

#891 passeggeri
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 891 entries, 0 to 890
    Data columns (total 12 columns):
     #   Column       Non-Null Count  Dtype  
    ---  ------       --------------  -----  
     0   PassengerId  891 non-null    int64  
     1   Survived     891 non-null    int64  
     2   Pclass       891 non-null    int64  
     3   Name         891 non-null    object 
     4   Sex          891 non-null    object 
     5   Age          714 non-null    float64
     6   SibSp        891 non-null    int64  
     7   Parch        891 non-null    int64  
     8   Ticket       891 non-null    object 
     9   Fare         891 non-null    float64
     10  Cabin        204 non-null    object 
     11  Embarked     889 non-null    object 
    dtypes: float64(2), int64(5), object(5)
    memory usage: 83.7+ KB
    


```python
#visualizzo prime righe
df.head

#cabin contiene molti valori mancanti(quasi tutti), anche età ha almeno 177 passeggeri senza età 
```




    <bound method NDFrame.head of      PassengerId  Survived  Pclass  \
    0              1         0       3   
    1              2         1       1   
    2              3         1       3   
    3              4         1       1   
    4              5         0       3   
    ..           ...       ...     ...   
    886          887         0       2   
    887          888         1       1   
    888          889         0       3   
    889          890         1       1   
    890          891         0       3   
    
                                                      Name     Sex   Age  SibSp  \
    0                              Braund, Mr. Owen Harris    male  22.0      1   
    1    Cumings, Mrs. John Bradley (Florence Briggs Th...  female  38.0      1   
    2                               Heikkinen, Miss. Laina  female  26.0      0   
    3         Futrelle, Mrs. Jacques Heath (Lily May Peel)  female  35.0      1   
    4                             Allen, Mr. William Henry    male  35.0      0   
    ..                                                 ...     ...   ...    ...   
    886                              Montvila, Rev. Juozas    male  27.0      0   
    887                       Graham, Miss. Margaret Edith  female  19.0      0   
    888           Johnston, Miss. Catherine Helen "Carrie"  female   NaN      1   
    889                              Behr, Mr. Karl Howell    male  26.0      0   
    890                                Dooley, Mr. Patrick    male  32.0      0   
    
         Parch            Ticket     Fare Cabin Embarked  
    0        0         A/5 21171   7.2500   NaN        S  
    1        0          PC 17599  71.2833   C85        C  
    2        0  STON/O2. 3101282   7.9250   NaN        S  
    3        0            113803  53.1000  C123        S  
    4        0            373450   8.0500   NaN        S  
    ..     ...               ...      ...   ...      ...  
    886      0            211536  13.0000   NaN        S  
    887      0            112053  30.0000   B42        S  
    888      2        W./C. 6607  23.4500   NaN        S  
    889      0            111369  30.0000  C148        C  
    890      0            370376   7.7500   NaN        Q  
    
    [891 rows x 12 columns]>




```python
#vedo statistiche descrittive per colonne numeriche
df.describe()

#è sopravvissuto il 38.4% dei passeggeri
#la dev st di età indica una ampia variazione d'età, così come negli altri vaori con dev alta, così come chi ha pagato il biglietto in Fare, ci sono differenze significative nel prezzo pagato
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>891.000000</td>
      <td>891.000000</td>
      <td>891.000000</td>
      <td>714.000000</td>
      <td>891.000000</td>
      <td>891.000000</td>
      <td>891.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>446.000000</td>
      <td>0.383838</td>
      <td>2.308642</td>
      <td>29.699118</td>
      <td>0.523008</td>
      <td>0.381594</td>
      <td>32.204208</td>
    </tr>
    <tr>
      <th>std</th>
      <td>257.353842</td>
      <td>0.486592</td>
      <td>0.836071</td>
      <td>14.526497</td>
      <td>1.102743</td>
      <td>0.806057</td>
      <td>49.693429</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.420000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>223.500000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>20.125000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>7.910400</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>446.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
      <td>28.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>14.454200</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>668.500000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>38.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>31.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>891.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>80.000000</td>
      <td>8.000000</td>
      <td>6.000000</td>
      <td>512.329200</td>
    </tr>
  </tbody>
</table>
</div>




```python
#conntrollo numero valori nulli per colonna
df.isnull().sum()
```




    PassengerId      0
    Survived         0
    Pclass           0
    Name             0
    Sex              0
    Age            177
    SibSp            0
    Parch            0
    Ticket           0
    Fare             0
    Cabin          687
    Embarked         2
    dtype: int64




```python
#analizzo colonne categoriche
colonne_cat=df.select_dtypes(include=['object']).columns
```


```python
#esplorazione valori per ciascuna colonna categorica
for col in colonne_cat:
    print("valori unici e frequenze per {col}:")
    print(df[col].value_counts())
    print("\n")
```

    valori unici e frequenze per {col}:
    Name
    Braund, Mr. Owen Harris                     1
    Boulos, Mr. Hanna                           1
    Frolicher-Stehli, Mr. Maxmillian            1
    Gilinski, Mr. Eliezer                       1
    Murdlin, Mr. Joseph                         1
                                               ..
    Kelly, Miss. Anna Katherine "Annie Kate"    1
    McCoy, Mr. Bernard                          1
    Johnson, Mr. William Cahoone Jr             1
    Keane, Miss. Nora A                         1
    Dooley, Mr. Patrick                         1
    Name: count, Length: 891, dtype: int64
    
    
    valori unici e frequenze per {col}:
    Sex
    male      577
    female    314
    Name: count, dtype: int64
    
    
    valori unici e frequenze per {col}:
    Ticket
    347082      7
    CA. 2343    7
    1601        7
    3101295     6
    CA 2144     6
               ..
    9234        1
    19988       1
    2693        1
    PC 17612    1
    370376      1
    Name: count, Length: 681, dtype: int64
    
    
    valori unici e frequenze per {col}:
    Cabin
    B96 B98        4
    G6             4
    C23 C25 C27    4
    C22 C26        3
    F33            3
                  ..
    E34            1
    C7             1
    C54            1
    E36            1
    C148           1
    Name: count, Length: 147, dtype: int64
    
    
    valori unici e frequenze per {col}:
    Embarked
    S    644
    C    168
    Q     77
    Name: count, dtype: int64
    
    
    


```python
#le persone imbarcate prettamente in S, poi C, Q
```


```python
eta_passeggeri=df[(df['Age']<15)| (df['Age'] > 60)]
morti_eta_range=eta_passeggeri[eta_passeggeri['Survived'] == 0].shape[0]
print(f"Numero di morti sotto i 15 o sopra i 60 anni: {morti_eta_range}")

```

    Numero di morti sotto i 15 o sopra i 60 anni: 50
    


```python
eta_passeggeri = df[(df['Age'] < 15) | (df['Age'] > 60)]

totale_eta_range = eta_passeggeri.shape[0]
print(totale_eta_range)

```

    100
    


```python
#chi ha pagato di più e si trovava in una classe più lussuosa è sopravvissuto di più?

correlation_fare_survival = df[['Fare', 'Survived']].corr()
print(correlation_fare_survival)

```

                  Fare  Survived
    Fare      1.000000  0.257307
    Survived  0.257307  1.000000
    


```python

```


```python
import matplotlib.pyplot as plt

#tasso di sopravvivenza per Classe di viaggio
pclass_survival = df.groupby('Pclass')['Survived'].mean()
plt.figure(figsize=(6, 4))  # Grafico più piccolo
pclass_survival.plot(kind='bar', color='skyblue')
plt.title("Tasso di sopravvivenza per Classe di viaggio")
plt.ylabel("Tasso di sopravvivenza")
plt.xlabel("Classe di viaggio")
plt.show()

#tasso di sopravvivenza per Sesso
sex_survival = df.groupby('Sex')['Survived'].mean()
plt.figure(figsize=(6, 4)) 
sex_survival.plot(kind='bar', color='lightcoral')
plt.title("Tasso di sopravvivenza per Sesso")
plt.ylabel("Tasso di sopravvivenza")
plt.xlabel("Sesso")
plt.show()

#tasso di sopravvivenza per Porto di imbarco
embarked_survival = df.groupby('Embarked')['Survived'].mean()
plt.figure(figsize=(6, 4))  # Grafico più piccolo
embarked_survival.plot(kind='bar', color='lightgreen')
plt.title("Tasso di sopravvivenza per Porto di imbarco")
plt.ylabel("Tasso di sopravvivenza")
plt.xlabel("Porto di imbarco")
plt.show()

#tasso di sopravvivenza per Numero di fratelli/sorelle a bordo
sibsp_survival = df.groupby('SibSp')['Survived'].mean()
plt.figure(figsize=(6, 4))  
sibsp_survival.plot(kind='bar', color='gold')
plt.title("Tasso di sopravvivenza per Numero di fratelli/sorelle a bordo")
plt.ylabel("Tasso di sopravvivenza")
plt.xlabel("Numero di fratelli/sorelle a bordo")
plt.show()

#tasso di sopravvivenza per gruppi di età
df['AgeGroup'] = pd.cut(df['Age'], bins=range(0, 85, 5), right=False)
age_survival = df.groupby('AgeGroup').agg(
    SurvivalRate=('Survived', 'mean'),
    Count=('Survived', 'size')
)

plt.figure(figsize=(8, 5))  
age_survival['SurvivalRate'].plot(kind='bar', color='lightblue')
plt.title("Tasso di sopravvivenza per gruppo di età")
plt.ylabel("Tasso di sopravvivenza")
plt.xlabel("Gruppo di età")
plt.show()

```


    
![png](output_15_0.png)
    



    
![png](output_15_1.png)
    



    
![png](output_15_2.png)
    



    
![png](output_15_3.png)
    


    C:\Users\bugli\AppData\Local\Temp\ipykernel_16104\3649613932.py:41: FutureWarning: The default of observed=False is deprecated and will be changed to True in a future version of pandas. Pass observed=False to retain current behavior or observed=True to adopt the future default and silence this warning.
      age_survival = df.groupby('AgeGroup').agg(
    


    
![png](output_15_5.png)
    



```python

```
